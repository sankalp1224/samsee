package com.pubnub.api.enums;


public enum PNHeartbeatNotificationOptions {

    NONE,
    FAILURES,
    ALL

}
