package com.pubnub.api.enums;

public enum PNReconnectionPolicy {

    NONE,
    LINEAR,
    EXPONENTIAL
}
